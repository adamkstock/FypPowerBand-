main code found in - 
FYP Handin\CC2640R2\ble5_project_zero_cc2640r2lp_app\Application