<?php
    echo "Welcome, I am connecting Android to PHP, MySQL test v002";
?>