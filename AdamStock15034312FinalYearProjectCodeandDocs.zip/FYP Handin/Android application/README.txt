main code found in - 
FYP Handin\Android application\FYPPowerband\app\src\main\java\com\example\fyppowerbandv002